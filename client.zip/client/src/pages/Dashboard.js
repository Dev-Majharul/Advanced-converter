import React from 'react';
import { Grid, Card, CardContent, CardActions, Typography, Button, Box } from '@mui/material';
import { Link as RouterLink } from 'react-router-dom';
import ImageIcon from '@mui/icons-material/Image';
import MovieIcon from '@mui/icons-material/Movie';
import PictureAsPdfIcon from '@mui/icons-material/PictureAsPdf';

const converterOptions = [
  {
    title: 'Image Converter',
    description: 'Convert between image formats like JPG, PNG, WEBP, GIF, etc. Apply effects and resize.',
    icon: <ImageIcon sx={{ fontSize: 60 }} />,
    path: '/image',
    formats: 'JPG, PNG, WEBP, BMP, TIFF, GIF',
  },
  {
    title: 'Video Converter',
    description: 'Convert videos to different formats. Extract audio, change resolution and more.',
    icon: <MovieIcon sx={{ fontSize: 60 }} />,
    path: '/video',
    formats: 'MP4, MKV, AVI, MOV, WEBM, GIF',
  },
  {
    title: 'PDF Tools',
    description: 'Merge, split, compress, and convert PDFs to and from other formats.',
    icon: <PictureAsPdfIcon sx={{ fontSize: 60 }} />,
    path: '/pdf',
    formats: 'PDF, DOC, DOCX, TXT, JPG, PNG',
  },
];

function Dashboard() {
  return (
    <Box>
      <Box mb={6} textAlign="center">
        <Typography variant="h3" component="h1" gutterBottom>
          Advanced File Converter
        </Typography>
        <Typography variant="h6" color="textSecondary" paragraph>
          Fast, reliable conversion between multiple file formats with advanced options
        </Typography>
      </Box>
      
      <Grid container spacing={4}>
        {converterOptions.map((option) => (
          <Grid item xs={12} sm={6} md={4} key={option.title}>
            <Card sx={{ 
              height: '100%', 
              display: 'flex', 
              flexDirection: 'column',
              transition: 'transform 0.2s ease-in-out, box-shadow 0.2s ease-in-out',
              '&:hover': {
                transform: 'translateY(-5px)',
                boxShadow: (theme) => `0 12px 20px -10px ${theme.palette.primary.main}40`,
              },
            }}>
              <Box 
                sx={{ 
                  display: 'flex', 
                  alignItems: 'center', 
                  justifyContent: 'center',
                  p: 3,
                  bgcolor: 'background.default',
                  color: 'primary.main',
                }}
              >
                {option.icon}
              </Box>
              <CardContent sx={{ flexGrow: 1 }}>
                <Typography gutterBottom variant="h5" component="h2">
                  {option.title}
                </Typography>
                <Typography variant="body2" color="textSecondary" paragraph>
                  {option.description}
                </Typography>
                <Typography variant="caption" color="textSecondary" component="p">
                  Supported formats: {option.formats}
                </Typography>
              </CardContent>
              <CardActions>
                <Button 
                  component={RouterLink} 
                  to={option.path} 
                  size="large" 
                  color="primary" 
                  variant="contained"
                  fullWidth
                >
                  Start Converting
                </Button>
              </CardActions>
            </Card>
          </Grid>
        ))}
      </Grid>
      
      <Box mt={8} textAlign="center">
        <Typography variant="h5" gutterBottom>
          Why choose our converter?
        </Typography>
        <Typography variant="body1" paragraph>
          Our advanced conversion tools offer high quality output with fine control over 
          the conversion process. All processing happens locally on your device for maximum privacy.
        </Typography>
      </Box>
    </Box>
  );
}

export default Dashboard; 